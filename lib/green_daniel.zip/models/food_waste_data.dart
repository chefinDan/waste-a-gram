import 'dart:io';

class FoodWasteData {
  String description;
  String weight;
  int quantity;
  File image;

  FoodWasteData({this.description, this.weight, this.quantity, this.image});
}