
const DARK_THEME = 'darkTheme';
const SWITCH_VALUE = 'switchValue';
const POSTS = 'posts';
const FILENAME = 'file_name';
const WEIGHT = 'weight';
const SUBMISSION_DATE = 'submission_date';
const IMAGE_URL = 'image_url';
const DESCRIPTION = 'description';
const TITLE = 'title';
const QUANTITY = 'quantity';
const KITTEN = 'kitten';
const RIGHT_TO_LEFT = 'rtl';
const LEFT_TO_RIGHT = 'ltr';
const LOADING_GIF = 'lib/assets/loading.gif';
const POST_LOCATION = 'location';
